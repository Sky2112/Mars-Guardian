# MarsGuardian design notes (handoff)

Values come from `node_2d.gd`. Change them there, not here.

## Colour tokens

| Token | Use |
|---|---|
| `ORANGE` | Brand, headings, mission pins, route line |
| `HAZ_RED` | Restricted areas, NO-GO, lost missions, warnings |
| `GOLD` | Caution zones, canyon pins |
| `GREEN` | Safe, GO, active missions, start marker |
| `BLUE` | Imagery and overview headings, basin pins |
| `ICE` | Guidance and GPS panel |
| `PANEL` / `PANEL_DARK` | Side panels / top and bottom bars |
| `DIM` | Secondary text |

## Type sizes

Title 22. Alert banner 15. Map labels 13. Body 12. Notes and captions 11.

## Zone styling

- **Restricted:** red fill at 20% opacity, 4 px outline drawn as alternating red and white 12 px dashes (hazard tape), label "RESTRICTED name" on a dark plate. Ring zones fill only the band and outline both edges, with the label on the top edge. Zones under 10 px show a red diamond marker.
- **Caution:** amber fill at 9%, 2.5 px amber and dark dashes, "CAUTION name" label.
- Zones larger than 40,000 px on screen are skipped to avoid huge geometry. Guidance text still warns.
- Colour is never the only signal: dashes, labels and the alert banner carry the meaning too.

## Guidance

- Cyan circle: estimated GPS position, radius is the accuracy. White arrow: true position and heading.
- Alert banner (top centre): red for stop, keep-out and caution. Green for arrival.

## Modes

| Control | Simple | Expert |
|---|---|---|
| Map, places, search, routes, guidance, zones toggle | yes | yes |
| Detail strength, sharpen, layer statistics | hidden | shown |
| Tile loading and resolution status (bottom bar) | hidden | shown |

Mode button is in the top bar. Default is Simple.
