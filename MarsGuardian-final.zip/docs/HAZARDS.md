# Danger zones and how navigation avoids them

All positions and sizes in `hazard_data.gd` are approximate and illustrative. They are **not** official NASA or ESA hazard maps. Do not use them for real mission planning.

## Two kinds of zone

| Kind | Examples | In the planner | On the map |
|---|---|---|---|
| **Restricted** (keep-out) | Canyon walls, volcano escarpment, collapse pits, sample cache, debris field, protected slope-streak craters | Impassable. Route goes around, or no route. | Red hazard-tape outline, red fill, "RESTRICTED" label |
| **Caution** | Dust-storm basins, soft-sand dunes, fractured ground, rock fields, wind | Costs more to cross (penalty 2.5 to 8). Avoided when a detour is cheaper. | Amber dashed outline, light fill, "CAUTION" label |

## What the research says

- **Slopes.** JPL reports the Mars Exploration Rovers used visual odometry to drive on slopes of 15 to 30 degrees, and both reached about 31 degrees. [JPL surface navigation](https://robotics.jpl.nasa.gov/what-we-do/flight-projects/mars-exploration-rovers/surface-navigation/)
- **Rocks and planning.** The rovers detect rocks with stereo vision, rate nearby terrain on a grid (GESTALT), and plan with the Field D* planner. The same JPL page describes avoiding untraversable terrain rather than explicit keep-out zones. MarsGuardian's grid A* with cost zones follows the same idea; keep-outs are an addition for protected and no-go ground.
- **Soft sand.** On 6 May 2009 Spirit hit sandy soil and sank to its hubcaps. Soft soil can hide under a layer of dust and is hard to see from the surface, so a freed rover could meet another trap. [Space.com](https://www.space.com/missionlaunches/090521-spirit-stuck.html) This is why dune and sand-trap zones carry high penalties (up to 8). Opportunity's 2005 "Purgatory Dune" entrapment is included from general knowledge and was not re-verified here.
- **Dust storms.** The 2007 global storm cut solar power so much that Spirit and Opportunity ran only a few minutes a day. Dust could also affect crew electronics and health, and storms can hide surface features. Regional and global storms are most likely in southern spring and summer, and global ones are rare. [JPL](https://www.jpl.nasa.gov/news/study-predicts-next-global-dust-storm-on-mars/) Dust zones raise route cost, and driving inside one degrades the simulated GPS.
- **Planetary protection.** COSPAR "Special Regions" are places where Earth microbes could plausibly grow, and recurring slope lineae are treated as uncertain regions, so vehicles must be sterile or stay out. This is why Hale, Newton and Horowitz slope-streak craters are keep-outs. [IFLScience summary](https://www.iflscience.com/the-special-regions-on-mars-where-it-is-forbidden-to-explore-for-good-reason-81791) (a secondary source; check the COSPAR policy text before relying on it).

## How the route avoids them

1. Keep-outs are blocked grid cells. Cost zones add a multiplier to the cell cost.
2. Priority changes the weighting: **safest** pays more detour to stay clear, **fastest** accepts more risk, **balanced** is in between.
3. A straight-line smoothing pass never cuts through a blocked cell or into costlier ground.
4. The planner reports what it went around, the closest approach to a keep-out, and a risk rating.
5. During a drive, the guidance panel re-checks distance to every keep-out from the *estimated* position and widens the margin by the GPS error.

## Known gaps

- Slope and rock data are not from real terrain models. A real build should read elevation and hazard rasters.
- Weather is static (Jezero site conditions). Live or forecast dust data would need a feed.
- Radiation and communications shadow are not modelled.
