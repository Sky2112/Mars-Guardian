# MarsGuardian: system design

Status: first integrated build. Written and parse-checked without a Godot editor, so it has **not been run in the engine yet**. Run the tests and a visual check before relying on anything here.

## Components

| File | Role | Depends on |
|---|---|---|
| `nav_system.gd` | Pure logic: geometry, hazard-aware A* route planner, turn-by-turn steps, simulated GPS (`GpsSim`). No UI. | nothing |
| `hazard_data.gd` | Data: restricted areas, caution hazards, extra Mars places. Illustrative, not official. | nothing |
| `node_2d.gd` | The app: tile map, places, Jezero zones, UI, drawing, drive simulation. | both of the above |
| `tests/test_nav.gd` | Headless tests for the two logic files. | both |

Rule: anything that decides *where it is safe to go* lives in `nav_system.gd` and `hazard_data.gd`, never in UI code, so it can be tested without a screen.

## Data flow

1. `_ready` builds `nav_hazards` once: every restricted area (hard keep-out), every global caution hazard (cost), and the Jezero slope, boulder, dust and wind sites. A site whose weather is NO-GO becomes a keep-out that may be crossed only as a last resort.
2. The Navigate tab calls `Nav.plan(start, goal, nav_hazards, opts)` with vehicle speed and priority (safest, balanced, fastest).
3. The result (path, steps, risk, warnings, avoided hazards) is drawn by `_draw_nav` and summarised in the side panel.
4. "Start simulated drive" creates a `GpsSim`, moves the vehicle along the path, and each frame computes position estimate, progress, next instruction and distance to the nearest keep-out.

## Navigation

- **Hard keep-outs** (cliffs, protected sites, pits, debris) are impassable cells. A ring (Olympus Mons escarpment) blocks only the band, not the summit inside it.
- **Cost zones** (dust, dunes, slopes, rocks, wind) raise the cost of crossing, so the planner goes around when a detour is cheaper than the risk.
- **Fallbacks:** a goal inside a keep-out is moved to the nearest permitted ground and flagged; a start inside one gets an exit route; if only NO-GO weather blocks the way, the route crosses it with a "hold position" warning.
- **Limits:** no ground routing above 78° latitude. No route is returned if keep-outs wall off the goal.
- **Guidance alerts** (drive mode): inside a keep-out = STOP; closer than the larger of 500 m or twice the GPS error = warning; poor GPS = slow down; inside a caution zone = warning with the reason.

## Simulated GPS

Mars has no GPS satellites. The simulator models what real vehicles use: visual-odometry drift while moving (faster in dust), correction at orbiter beacon fixes (lost in dust), and a capped error. The map shows the estimated position (cyan circle = accuracy) and the true position (white arrow). The crew would only see the estimate.

## Interface modes

- **Simple** (default): map, places, layers, routes, guidance. Hides tile statistics, sharpening and detail-strength controls.
- **Expert:** everything, for people who tune imagery or need load diagnostics.

## Failure modes to watch

| Risk | Current handling |
|---|---|
| Tile server (trek.nasa.gov) unreachable | Tiles are cached in `user://tilecache`; a fresh install with no network shows a blank map. Ship an offline tile pack before any real use. |
| Planner runs on the main thread | A long global route can pause the UI. Not measured yet. Move to a thread if it does. |
| Position error larger than clearance | Alerts widen the safety margin with the GPS error. |
| Wrong or stale hazard data | Data is illustrative. Needs a sourced, versioned dataset with review before operational use. |

## Verdict: is Godot suitable?

**For this app as a crew-facing map, route-planning and training or simulation tool: yes.** Godot gives a 2D renderer, custom drawing, UI, one-click export to Windows, Linux, macOS, Android and web, a small download, an MIT licence, and fast iteration. The logic core is already separated and testable headless.

**As the safety-critical layer: no.** Reasons:
- No certified or safety-subset toolchain, and GDScript is dynamically typed, so many mistakes only appear at runtime.
- Script code is effectively single-threaded unless you build threading yourself, so heavy planning can stall the UI.
- Limited accessibility support (screen readers, large-text modes) compared with native toolkits.
- Frame hitches are possible during tile decoding on slow hardware.

**Recommendation:** keep Godot as the display and interaction layer; treat its guidance as advisory, with authoritative hazard data and vehicle control elsewhere. If the planner grows, move it to a worker thread, C# or a native extension. Add an offline data pack. Confidence: medium, based on reading the code and general knowledge of the engine. I have not profiled this app.

## Next steps

1. Open in Godot 4.7, run `godot --headless --path . --script tests/test_nav.gd`, then play the app and check each tab.
2. Measure planner time on a global route; thread it if over about 100 ms.
3. Add manual driving with the GPS estimate so off-route and reroute can be tested for real.
4. Replace illustrative hazard data with sourced, versioned data.
